# FreeboxTV Starter Kotlin Project

Ce projet permet de :
- Télécharger et parser une playlist M3U Freebox
- Afficher les chaînes disponibles
- Lire une configuration JSON locale (favoris, index par défaut)

### Prochaines étapes
- Intégrer le code dans une application Android TV
- Ajouter ExoPlayer pour la lecture des flux
- Gérer les favoris et la lecture automatique